#include <iostream>
#include <cstdlib>
#include <locale>
#include "functions.h"

using namespace std;


/*
    Returns temperature in Fahrenheit
    T(f) = 9/5 T(c) + 32
    You do not have to verify that the input is a valid 
       Celsius Temperature
    Input: double representing a temperature in 
    Returns: double that represents the input's equivalent 
       Fahrenheit temperature
*/
double convertCelsiusToFahrenheit(double tempC) {
    double tempF = 0;
    tempF = (tempC*(9.0/5.0)) + 32.0;
    return tempF; // replace 0 with actual return value
}
/*
    Returns temperature in Celsius
    T(c) = 5/9 (T(f) - 32)
    You do not have to verify that the input is a valid 
       Fahrenheit Temperature
    Input: double representing a temperature in Fahrenheit
    Returns: double that represents the input's equivalent 
       Celsius temperature
*/
double convertFahrenheitToCelsius(double tempF) {
    double tempC = 0;
    tempC = (tempF - 32.0) * (5.0/9.0);
    return tempC; // replace 0 with actual return value
}
/*
    Get input from user, call appropriate functions to calculate results
      and output those results.
*/
void processTemperature() {
	cout << "Please enter a temperature: " ;
	double temp = 0;
	cin >> temp;
	cout << "Is that Celsius or Fahrenheit? [F/C] " ;
	char cORf;
	cin >> cORf;
	char cf = tolower(cORf);
  char CoF = toupper(cORf);
	if (cf == 'c'){
		cout << temp << "C" << " is " << convertCelsiusToFahrenheit(temp) << "F." << endl;
	}
	else if (cf == 'f'){
		cout << temp << "F" << " is " << convertFahrenheitToCelsius(temp) << "C." << endl;
	}
  else{
    cout << CoF << " is not a supported temperature scale." << endl;
  }
}

/*
    Calculates the sum of integers between 0 and input number
    For example if the number is 4, then the output will be 0+1+2+3+4 
       which is 10
    For example if the number is -3, then the output will be 0-1-2-3 
       which is -6
    Input: int
    Output: int representing the sum of integers between 0 and the input
*/
int sums(int num) {
	int total = 0;
  int posNum = abs(num);
   for (int i=0; i<=posNum; i++){
   	total = total + i;
   }
   if (num < 0){
    total = 0-total;
   }
    return total; // replace 0 with actual return value
}
/*
    Get input from user, call appropriate functions to calculate results
      and output those results.
*/
void processSums() {
	cout << "Get sum from zero to what integer? " ;
	int integer;
	cin >> integer;
	cout << "The sum from zero to " << integer << " is " << sums(integer) << "." << endl; }

/*
    Calculates the sum of digits in a number
    If the number is negative, then negative sum will be output
    For example if the number is 4235, then the output will be 4+2+3+5 
       which is 14
    For example if the number is -367, then the output will be -(3+6+7) 
       which is -16
    Input: int
    Output: int representing sum of digits in a number that is negative 
       if the input is negative
*/
int sumOfDigits(int num) {
        int total = 0;
        int last = 0;
        int finalNum = abs(num);
        while (finalNum != 0){
        	last = finalNum%10;
        	total = total + last;
        	finalNum /= 10;
        }
        if(num<0){
          total = 0- total;
        }
        return total;  // replace 0 with actual return value
}
/*
    Get input from user, call appropriate functions to calculate results
      and output those results.
*/
void processSumOfDigits() {
	cout << "Get sum of digits for what integer? ";
	int num;
	cin >> num;
	cout << "The sum of digits for " << num << " is " << sumOfDigits(num) << "." << endl ;

}

/*
    Determines whether a number is prime or not
    Input: integer
    Output: boolean that is true if the input is prime, and false otherwise
*/
bool is_prime(int num) {
  int i;
  bool primeVal = true;

  for(i = 2; i <= num / 2; ++i)
  {
      if(num % i == 0)
      {
          primeVal = false;
          break;
      }
  }

    return primeVal;  // replace false with actual return value
}
/*
    Get input from user, call appropriate functions to calculate results
      and output those results.
*/
void processPrime() {
	cout << "Determine if what integer is prime? " ;
	int primeInt;
	cin >> primeInt;
	if (is_prime(primeInt) == true){
		cout << primeInt << " is prime." << endl;
	}
	else if (is_prime(primeInt) != true){
		cout << primeInt << " is not prime." << endl;
	}

}

void printMenu() {
    cout << endl;
    cout << "Please choose from the following: " << endl;
    cout << " T - Convert temperature" << endl;
    cout << " S - Sum numbers from 0 to designated integer" << endl;
    cout << " D - Sum of digits in integer" << endl;
    cout << " P - Prime number" << endl;
    cout << " Q - Quit" << endl;
    cout << endl;
    cout << "Please enter choice: ";
}

/*
    Based on input, call appropriate "process" function for menu choices.
    
    switch statements work well in this context, 
      but if statements can work as well.
*/
void processMenuChoice(char choice) {

	choice=tolower(choice);
	switch (choice) {
		case 't': 
			processTemperature();
		break;

		case 's':
			processSums();
		break;

		case 'd':
			processSumOfDigits();
		break;

		case 'p': 
			processPrime();
		break;

		case 'q':
			break;
		
		default: 
			cout << "Please enter a valid choice." << endl;
	}
}

